# Ghi chú kiểm thử ROLL GARDEN STOCK v2

## Bộ PDF mẫu
- File: Packing List 50 trang do người dùng cung cấp.
- Kiểm tra văn bản/bố cục PDF mẫu: 50 trang, mỗi trang có một Order ID; trang 30 có hai sản phẩm, do đó kỳ vọng 50 đơn và 51 dòng sản phẩm.
- Parser được chạy trên 50 trang với tọa độ từ vùng chữ PDF để mô phỏng dữ liệu có bounding box của ML Kit. Kết quả: **50/50 Order ID, 51 dòng sản phẩm, 0 dòng mất mã đơn, 0 dòng tên cây không nhận diện trong bộ mẫu**. Đây là kiểm thử logic theo bố cục mẫu; vẫn cần xác nhận sau khi OCR chạy trên điện thoại thật vì kết quả ML Kit có thể khác văn bản gốc.

## Các trường hợp đã kiểm tra
- Trang 1: `Combo 2 chậu Dương Sỉ`, Qty 1 -> 2 cây.
- Trang 7: Product Name ghi Combo 2, SKU ghi Combo 4 -> lấy Combo 2 từ Product Name, ra 2 cây.
- Trang 12: tên Product Name là Ruby Đỏ; SKU ghi Combo 4 tặng 1, Qty 1 -> 5 cây.
- Trang 22: Combo 5 Cẩm tú mai, Qty 2 -> 10 cây.
- Trang 30: hai sản phẩm trong cùng Order ID được tách thành hai dòng và đều có Qty riêng.
- Nguyệt quế Thái chiều cao 15–20 cm được map sang C7; `2 chậu C7` làm pack count 2.

## Giới hạn / an toàn
- Bộ nhận diện giữ tọa độ từng element OCR để phân biệt Product Name, SKU, Seller SKU và Qty. SKU không ghi đè combo nếu Product Name đã ghi combo rõ ràng; SKU chỉ là nguồn dự phòng khi Product Name không nêu số cây trong combo.
- Nếu tiêu đề có nhiều kích cỡ (ví dụ C6, C7), kích cỡ được lấy theo biến thể được đánh dấu cần đối chiếu.
- Chưa có APK build trong môi trường chỉnh sửa này; GitHub Actions phải xác nhận build trước khi cài đặt.
