# ROLL GARDEN STOCK — Android source

## Chức năng đã có trong source
- Ứng dụng Android riêng, package `com.rollgarden.stock`; không đụng đến ROLL CÂY CẢNH.
- Đọc PDF từ điện thoại: ưu tiên trích xuất lớp chữ có sẵn bằng PDFBox-Android để giữ nguyên Order ID, Product Name, quy cách và Qty; chỉ dùng Android `PdfRenderer` + ML Kit OCR nếu PDF là bản scan. Giới hạn hiện tại: 25 MB / 80 trang cho mỗi file.
- Đối chiếu tên cây với catalog 96 cặp tên/quy cách đã trích từ file source ROLL CÂY CẢNH bạn cung cấp. Có màn hình chỉnh sửa danh mục và nhập JSON catalog/backup có mảng `catalog`.
- Bảng kết quả cho phép sửa mã đơn, tên cây, quy cách, số lượng. Dòng chưa đủ căn cứ được đánh dấu cần kiểm tra.
- Bảng tổng nhu cầu theo tên cây/quy cách; bảng combo theo số cây của từng loại trong một đơn; thống kê tổng cây/đơn. Các dòng trùng cây/quy cách trong cùng mã đơn được cộng trước khi phân nhóm.
- Quản lý tồn kho khả dụng tại máy; tính lượng cần bổ sung; xuất CSV/JSON vào Downloads/ROLL GARDEN STOCK.
- Tự lưu dữ liệu cục bộ; nhận diện dấu vân tay file đã nhập để cảnh báo khi nhập lại.

## Lưu ý quan trọng
Bộ parser đã được kiểm thử với lớp chữ PDF Packing List 50 trang: 50 đơn, 51 dòng sản phẩm và 151 cây tính theo combo × Qty. Ứng dụng ưu tiên trích xuất text trực tiếp từ PDF bằng PDFBox-Android để tránh sai chữ/số do OCR; ML Kit là phương án dự phòng cho PDF scan. Các dòng chưa rõ tên/quy cách vẫn được đánh dấu kiểm tra. Khi không có mã đơn, ứng dụng dùng mã `TRANG_###` và gắn cờ để người dùng kiểm tra; không tự chế tên cây khi không khớp catalog. Trước khi dùng số liệu để chốt tồn kho, hãy kiểm tra những dòng được gắn cờ.

## Build APK trên GitHub từ điện thoại
1. Tạo repository mới tên `ROLL-GARDEN-STOCK` (không dùng repository ROLL CÂY CẢNH).
2. Upload toàn bộ nội dung thư mục này lên nhánh `main`.
3. Vào tab **Actions** → workflow **Build ROLL GARDEN STOCK APK** → **Run workflow**.
4. Khi job xanh, mở build run → **Artifacts** → tải `ROLL-GARDEN-STOCK-debug-apk`.

Workflow dùng JDK 17, Gradle 8.9 và Android SDK; cần kết nối internet trong GitHub Actions để tải plugin/dependency lần đầu.

## Cấu trúc chính
- `app/src/main/assets/index.html`: giao diện và bộ phân tích/nhóm dữ liệu.
- `app/src/main/assets/plant_catalog_seed.json`: catalog ban đầu.
- ``app/src/main/java/com/rollgarden/stock/MainActivity.java`: chọn PDF, trích xuất text bằng PDFBox-Android, OCR dự phòng bằng ML Kit và lưu báo cáo.
- `.github/workflows/build-apk.yml`: GitHub Actions build APK debug.

Xem `VALIDATION_NOTES.md` để biết các kiểm tra logic đã chạy và các giới hạn chưa thể xác nhận trong môi trường hiện tại.


## CẬP NHẬT APK TỰ ĐỘNG TỪ GITHUB RELEASE

Ứng dụng kiểm tra GitHub Releases khi mở. Nếu có bản mới, ứng dụng hỏi người dùng tải/cài đặt; Android vẫn yêu cầu người dùng xác nhận cài APK. Không thể cài đặt âm thầm.

### Cấu hình bắt buộc một lần

Workflow dùng cùng một khóa ký cho mọi bản cập nhật. Trong GitHub repo `tiennt9939/Stock`, vào Settings → Secrets and variables → Actions → New repository secret và tạo 4 secret:

- `KEYSTORE_BASE64`: nội dung file keystore đã mã hóa Base64 (tạo một keystore ổn định; không được thay khóa sau khi phát hành).
- `KEYSTORE_PASSWORD`: mật khẩu keystore.
- `KEY_ALIAS`: alias của khóa.
- `KEY_PASSWORD`: mật khẩu khóa.

Không đưa file keystore/mật khẩu vào source công khai. Nếu APK đã cài trên điện thoại được ký bằng khóa debug tự sinh của GitHub Actions, bản release ký bằng khóa riêng sẽ không thể cập nhật đè lên bản đó. Cần gỡ APK cũ rồi cài bản release đầu tiên; dữ liệu cục bộ có thể mất khi gỡ ứng dụng, hãy xuất/sao lưu trước. Sau bản release đầu tiên, các bản sau dùng cùng khóa sẽ cập nhật được.

Mỗi lần push source vào `main`, workflow build APK release ký cố định và xuất asset `app-release.apk` lên GitHub Release mới nhất. Ứng dụng sẽ phát hiện bản mới ở lần mở kế tiếp.
