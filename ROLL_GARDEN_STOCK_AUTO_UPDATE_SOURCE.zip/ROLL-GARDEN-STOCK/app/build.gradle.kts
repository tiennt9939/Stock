plugins { id("com.android.application") }

android {
    namespace = "com.rollgarden.stock"
    compileSdk = 35
    defaultConfig {
        applicationId = "com.rollgarden.stock"
        minSdk = 23
        targetSdk = 35
        versionCode = (project.findProperty("BUILD_NUMBER") as String? ?: "3").toInt()
        versionName = project.findProperty("BUILD_NAME") as String? ?: "1.1.0"
    }
    signingConfigs {
        create("release") {
            val storeFilePath = System.getenv("RGS_KEYSTORE_FILE")
            if (!storeFilePath.isNullOrBlank()) {
                storeFile = file(storeFilePath)
                storePassword = System.getenv("RGS_KEYSTORE_PASSWORD")
                keyAlias = System.getenv("RGS_KEY_ALIAS")
                keyPassword = System.getenv("RGS_KEY_PASSWORD")
            }
        }
    }
    buildTypes {
        getByName("release") {
            signingConfig = signingConfigs.getByName("release")
            isMinifyEnabled = false
        }
    }
}

dependencies {
    implementation("com.google.mlkit:text-recognition:16.0.1")
    implementation("com.tom-roush:pdfbox-android:2.0.27.0")
    implementation("androidx.core:core:1.15.0")
}
