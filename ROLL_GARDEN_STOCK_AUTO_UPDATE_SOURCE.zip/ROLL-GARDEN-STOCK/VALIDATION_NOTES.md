# Kiểm thử ROLL GARDEN STOCK — bản sửa nhận diện PDF

## PDF gốc đã dùng
- 50 trang Packing List đính kèm trong cuộc trò chuyện.
- Mỗi trang là một Order ID; trang 30 có hai sản phẩm.

## Kiểm thử parser trên lớp chữ PDF
- 50 trang được xử lý.
- 50 mã đơn duy nhất.
- 51 dòng sản phẩm được tách.
- Tổng nhu cầu theo combo × Qty: 151 cây.
- 11 phép kiểm thử logic đều đạt: trang đầu vào, số đơn, số dòng, tổng cây, đơn hai sản phẩm, Dương Sỉ, Cẩm tú mai C6/C9, Ruby đỏ Combo 4 tặng 1, và Cẩm tú mai Qty 2.

## Quy tắc nhận diện trong bản sửa
- Ưu tiên đọc trực tiếp lớp chữ có sẵn của PDF bằng PDFBox-Android; ML Kit chỉ là phương án dự phòng cho PDF scan.
- Product Name được dùng để nhận diện tên cây.
- Nếu Product Name ghi Combo 2 nhưng SKU ghi Combo 4, lấy Combo 2 theo Product Name.
- Combo 4 tặng 1 = 5 cây; Qty được nhân với số cây trong combo.
- Dương Sỉ dùng quy cách chiều cao 30–45 cm theo nhãn.
- Nguyệt quế Thái C7 lấy quy cách trên nhãn; số chậu và Qty được tính riêng.
- Đơn có nhiều sản phẩm giữ chung Order ID nhưng có dòng sản phẩm riêng.

## Giới hạn kiểm định
- Parser JS được chạy kiểm thử với văn bản trích xuất từ PDF gốc, không phải output OCR mô phỏng.
- Đã chỉnh sửa Android Java và Gradle để đọc text layer trước, nhưng chưa build APK mới trong môi trường này vì không có Android SDK/Gradle cài sẵn. GitHub Actions cần xác nhận build thành công trước khi cài trên điện thoại.
- Với PDF scan không có lớp chữ, fallback OCR vẫn có thể cần kiểm tra thủ công các trường bị nhòe hoặc thiếu.
